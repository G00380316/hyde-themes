# pixelitos-icon-theme
 16-bit style icon theme
  ## Note
  - pixelitos-icon-theme is under constantly development,
 if you want a icon to be added, please make an issue
 
 ## Installation
 
`git clone https://github.com/ItzSelenux/pixelitos-icon-theme`

`mv ~/pixelitos-icon-theme ~/.local/share/icons/pixelitos`

- the folder needs to be called "pixelites", for the color change script to work properly
