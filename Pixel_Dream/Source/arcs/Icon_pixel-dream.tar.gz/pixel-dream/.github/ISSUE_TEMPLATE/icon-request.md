---
name: Icon Request
about: Request an icon
title: "<Program Name> Icon Request"
labels: Icon Request
assignees: ''

---

**to check internal name please check ```/usr/share/applications``` or ```~/.local/share/applications```**

Icon Name: [e.g. Inkscape]
Program Name: [e.g. org.inkscape.Inkscape]

**(Optional) send Program logo**
